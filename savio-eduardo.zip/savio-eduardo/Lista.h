#ifndef LISTA_H_
#define LISTA_H_
//#include "Cliente.h"

typedef struct cliente Cliente;

void pegaInfoCli(Cliente **l, int t);
void inicializaCli(Cliente **l);
int estaVazioCli(Cliente **l);
//typedef struct representante Representante;

#endif /* LISTA_H_ */